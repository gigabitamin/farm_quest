# 회원가입 로그인

from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from .models import User, UsersAppUser
from .forms import CustomUserCreationForm, UserForm, UserInfoForm

# 마이페이지
# 로그인 관련
from imaplib import _Authenticator
from django.views.generic.edit import DeleteView
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.signals import user_logged_in
from django.conf import settings

# 네이버 데이터랩 트렌드 그래프
from .templatetags.naver_datalab import *
import io
import base64

# 로그인 메일링
from django.dispatch import receiver
from django.core.mail import send_mail
import smtplib  # SMTP 사용을 위한 모듈
import re  # Regular Expression을 활용하기 위한 모듈
from email.mime.multipart import MIMEMultipart  # 메일의 Data 영역의 메시지를 만드는 모듈
from email.mime.text import MIMEText  # 메일의 본문 내용을 만드는 모듈
from email.mime.image import MIMEImage  # 메일의 이미지 파일을 base64 형식으로 변환하기 위한 모듈

# 기타
from datetime import datetime, timedelta
import os
from django.shortcuts import get_object_or_404, render, redirect



def sign_in(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)

        if form.is_valid():
            login(request, form.get_user())
            return redirect('index')
        
    else:
        form = AuthenticationForm()

    return render(request, 'users_app/sign_in.html', {'form':form})

def sign_out(request):
    logout(request)
    return redirect('index')

def sign_up(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            login(request, form.save())
            return redirect('sign_in')
    else:
        form = CustomUserCreationForm()

    return render(request, 'users_app/sign_up.html', {'form':form})

def sign_up2(request):   
    if request.method == 'POST':
        
        username = request.POST['username']        
        email = request.POST['email']
        password = request.POST['password']
        user_name = request.POST['user_name']
        user_phone = request.POST['user_phone']
        user_address = request.POST['user_address']
        preferred_region_no = request.POST['preferred_region_no']
        preferred_accommodation_type_no = request.POST['preferred_accommodation_type_no']
        preferred_tour_theme_type_no = request.POST['preferred_tour_theme_type_no']

        user = UserForm(request.POST)
        # 매개변수는 3개만 전달 가능
        # 순서 주의 : username, email, password

        user = User.objects.create_user(username, email, password)
        # 3개 외 나머지는 별도로 추가
        user.user_name = user_name
        user.user_phone = user_phone
        user.user_address = user_address
        user.preferred_region_no = preferred_region_no
        user.preferred_accommodation_type_no = preferred_accommodation_type_no
        user.preferred_tour_theme_type_no = preferred_tour_theme_type_no
            
        user.save()        

        return redirect('sign_in')
    
    else:
        form = UserForm()

    return render(request, 'users_app/sign_up2.html', {'form':form})







# 마이페이지에 유저의 선호도 지정 키워드 -> 구글트렌드 관련검색어, 네이버 검색트렌드 에 입력 후 반환 된 결과 matplotlib 그래프로 추가
@login_required
def my_page(request):
    user_info = request.user  # 현재 로그인한 사용자
    client_id = "XZc22eND2hDwZOrJ3uAv"
    client_secret = "Ys7etJVJZ5"
    
    now = datetime.now()
    last_date_str = now.strftime("%Y-%m-%d") # 현재 시각
    first_date = now - timedelta(days=365 * 7) # 7년전, 년도 수 다르게 하려면 숫자 7변경, but 7년 이상 넘어갈 시 네이버에서 400 오류
    first_date_str = first_date.strftime("%Y-%m-%d")

    api = NaverDataLabOpenAPI(client_id, client_secret)

    group_dict = {
        'groupName': f'{user_info.preferred_accommodation_type_no.preferred_accommodation_type} {user_info.preferred_tour_theme_type_no.preferred_tour_theme_type} 통합 검색 트렌드',
        'keywords': [user_info.preferred_accommodation_type_no.preferred_accommodation_type, user_info.preferred_tour_theme_type_no.preferred_tour_theme_type]
    }
    api.add_keyword_groups(group_dict)

    startDate = first_date_str
    endDate = last_date_str
    timeUnit = "month"
    device = "pc"
    ages = ["1"]
    gender = "m"

    api.get_data(startDate, endDate, timeUnit, device, ages, gender)

    img_data = api.month_trend()

    return render(request, 'users_app/my_page.html', {'user_info' : user_info, 'img_data': img_data, 'last_date_str':last_date_str, 'first_date_str':first_date_str})



# 회원정보 수정
@login_required
def my_page_update(request, id):  
    user_info = get_object_or_404(UsersAppUser, pk=id)
    if request.method == "POST":
        user_form = UserInfoForm(request.POST, instance=user_info)
        if user_form.is_valid():
            user_info = user_form.save(commit=False)
            user_info.save()
            return redirect('index')
    else:
        user_form = UserInfoForm(instance=user_info)
    
    return render(request, 'users_app/my_page_update.html', {'user_form':user_form, 'user_info_update':user_info})



# 회원정보 탈퇴 페이지로 이동 후 회원정보 삭제

class MyPageDeleteView(DeleteView):
    model = UsersAppUser
    success_url = 'index'  # 회원 탈퇴 후 리디렉션할 URL

    # 'my_page_delete_confirm.html' 템플릿을 사용하도록 설정
    template_name = 'users_app/my_page_delete_confirm.html'

@login_required
def my_page_delete_move(request, id):
    user_info = get_object_or_404(UsersAppUser, pk=id)        
    return render(request, 'users_app/my_page_delete_confirm.html', {'user_info':user_info})

@login_required
def my_page_delete(request):
    if request.method == "POST":
        user = request.user  # 현재 로그인한 사용자
        user.delete()  # 사용자 정보 삭제
        return redirect('index')  # 탈퇴 후 리디렉션할 URL
    return render(request, 'users_app/my_page_delete_confirm.html')



# 로그인 시 유저에게 이메일 발송 - 프로젝트 종료로 메일링 기능 임시 정지

# @receiver(user_logged_in)
# def send_login_email(sender, request, user, **kwargs):
#     # 사용자 정보에서 이메일 주소 가져오기
#     user_email = user.email
#     inneats_user_id = user.username
#     # 이메일 보내기
#     send_mail(user_email, inneats_user_id)

# 로그인시 해당 유저 이메일로 자동 메일 발송
def send_mail(to_email, inneats_user_id):
    # py 파일명이 email 일 경우 에러나니 변경할 것
    # 해당 기능 전체를 함수화해서 사용할 것, Class modeul로 빼는 것도 고려
    # def sendEmail (from_email, to_email, from_email_password, inneats_user_id): 

    # Gmail 계정에서 IMAP 설정
    # https://mail.google.com/mail/u/0/#settings/fwdandpop
    # 해당 설정에서 IMAP 을 사용상태로 open 해줘야 타클라이언트에서 gmail 전송 사용가능
    # https://myaccount.google.com/security
    # app_password = '본인 app password' # 2차 로그인을 하는 계정일 시 구글 보안설정에서 app 패스워드 설정 후 입력 필요

    # 발송자 정보
    from_email = 'gigabitamin@gmail.com' # 보낼 계정
    from_email_password = 'kywqqehhchzcqszu'

    # 수신자 정보
    to_email = 'myanyhoney@gmail.com' # 수신할 계정 # 여러명에게 보낼 땐 [] 로 리스트 처리
    inneats_user_id = inneats_user_id

    # 보낼 내용
    now = datetime.now()
    send_subject = f'{inneats_user_id}님께서 {now}에 InnEats에 로그인 하셨습니다' # 제목
    text = f"\
        안녕하세요 {inneats_user_id}님\n\
        InnEats에 오신 것을 환영합니다"
    html = f"<html><body><h1>{now}</h1><p>{text}</p></body></html>"

    # 서버와 연결
    smtp_server = 'smtp.gmail.com' # gmail smtp 주소
    smtp_port = 465  # gmail smtp 포트번호
    server = smtplib.SMTP_SSL(smtp_server, smtp_port) # SMTP 객체
    
    # 로그인
    server.login(from_email, from_email_password)
    
    # 메일 기본 정보 설정
    msg = MIMEMultipart("alternative")
    msg["Subject"] = send_subject
    msg["From"] = from_email
    msg["To"] = to_email

    # 메일 본문 _email내용
    text_part = MIMEText(text, "plain")
    html_part = MIMEText(html, "html")
    msg.attach(text_part)
    msg.attach(html_part)
    
    # 이미지 파일 추가
    # image_path = "{% static 'img/logo/inneats/InnEats_logo_temp.png' %}" --> load static 실행 안됨, 절대 결로 or 상대 경로 처리
    # image_path = "C:\djangoWorkspace/InnEats_logo_temp.png"
    # image_path = "../../../static/img/logo/inneats/InnEats_logo_temp.png"
    
    image_path = os.path.join(settings.STATIC_ROOT, 'image/logo/farm_quest_site.png')
    
    # 'rb' read binary, 2진 데이터로 처리 -> 이미지 로딩 가능
    with open(image_path, 'rb') as file: 
        img = MIMEImage(file.read())
        img.add_header('Content-Disposition', 'attachment', filename=image_path)
        msg.attach(img)
    
    # 받는 메일 유효성 검사 거친 후 메일 전송
    # 올바른 형식으로 보내는지 정규식 검사
    reg = "^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9]+\.[a-zA-Z]{2,3}$"
    try:
        if re.match(reg, to_email):
            server.sendmail(from_email, to_email, msg.as_string())
            print("정상적으로 메일이 발송되었습니다")
        else:
            print("받으실 메일 주소를 정확히 입력하십시오")
    except Exception as e:
        print("error", e)
    
    # smtp 서버 연결 해제
    server.quit()
